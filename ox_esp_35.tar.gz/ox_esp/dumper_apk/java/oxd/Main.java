package oxd;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.*;
import java.io.*;

/** Standalone runtime dumper UI. Starts ox_dumper in --wait mode detached (nohup) so it survives this app being
 *  killed, and tails its log through su. The dumper waits until the REAL decrypted global-metadata appears in the
 *  game's memory (a magic-valid blob >= 256KB; the 4KB stub never qualifies), then dumps it + libil2cpp.so. */
public class Main extends Activity {
    static final String LOG = "/sdcard/Download/ox_dump.log";
    final Handler ui = new Handler(Looper.getMainLooper());
    TextView logTv; EditText pkgEt; volatile boolean polling;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(14, 14, 20));
        int p = (int) (14 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p * 2, p, p);

        TextView t = new TextView(this);
        t.setText("OX DUMPER  (runtime, needs root)");
        t.setTextColor(Color.WHITE); t.setTextSize(18); t.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(t);

        TextView how = new TextView(this);
        how.setText("1) жми START\n2) запусти игру и ЗАЙДИ В МАТЧ (не меню) -- дампер сам поймает настоящую метадату\n3) файлы в /sdcard/Download: *.libil2cpp.so.dump, *.global-metadata.*.dump");
        how.setTextColor(Color.rgb(170, 170, 190)); how.setTextSize(12);
        how.setPadding(0, p / 2, 0, p / 2);
        root.addView(how);

        pkgEt = new EditText(this);
        pkgEt.setText("oxide,hyperhug");
        pkgEt.setTextColor(Color.WHITE); pkgEt.setSingleLine(true);
        root.addView(pkgEt);

        LinearLayout row = new LinearLayout(this);
        Button start = new Button(this); start.setText("START");
        Button stop = new Button(this); stop.setText("STOP");
        row.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(stop, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        ScrollView sv = new ScrollView(this);
        logTv = new TextView(this);
        logTv.setTextColor(Color.rgb(120, 255, 160)); logTv.setTextSize(11); logTv.setTypeface(Typeface.MONOSPACE);
        logTv.setText("idle");
        sv.addView(logTv);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        start.setOnClickListener(v -> start());
        stop.setOnClickListener(v -> new Thread(() -> { sh("pkill -f /data/local/tmp/ox_dumper"); ui.post(() -> logTv.append("\n[stopped]")); }).start());
    }

    @Override protected void onResume() { super.onResume(); poll(); }
    @Override protected void onPause() { polling = false; super.onPause(); }

    void start() {
        final String pkg = pkgEt.getText().toString().trim();
        new Thread(() -> {
            try {
                File dst = new File(getFilesDir(), "ox_dumper");
                try (InputStream in = getAssets().open("ox_dumper"); FileOutputStream out = new FileOutputStream(dst)) {
                    byte[] buf = new byte[65536]; int k; while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
                }
                dst.setReadable(true, false);
                sh("pkill -f /data/local/tmp/ox_dumper; cp '" + dst.getAbsolutePath() + "' /data/local/tmp/ox_dumper && chmod 755 /data/local/tmp/ox_dumper"
                   + " && mkdir -p /sdcard/Download && rm -f " + LOG
                   + " && (nohup /data/local/tmp/ox_dumper --wait '" + pkg + "' /sdcard/Download > " + LOG + " 2>&1 &)");
                ui.post(this::poll);
            } catch (Exception e) { ui.post(() -> logTv.setText("error: " + e)); }
        }).start();
    }

    void poll() {
        if (polling) return;
        polling = true;
        new Thread(() -> {
            while (polling) {
                final String s = sh("cat " + LOG + " 2>/dev/null");
                ui.post(() -> { if (!s.isEmpty()) logTv.setText(s); });
                try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
            }
        }).start();
    }

    static String sh(String cmd) {
        try {
            Process pr = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(pr.getInputStream()));
            StringBuilder sb = new StringBuilder(); String l;
            while ((l = br.readLine()) != null) sb.append(l).append('\n');
            pr.waitFor();
            return sb.toString();
        } catch (Exception e) { return "sh error: " + e; }
    }
}
