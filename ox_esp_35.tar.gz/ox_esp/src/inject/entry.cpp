// astral_internal.so: loaded INTO the game process by astral_inject (ptrace+dlopen). Runs OxGame against our
// own address space (LocalMem, no /proc/pid/mem round trip) and serves the exact same line protocol ox_core
// speaks over stdout/stdin, but over an abstract Unix domain socket -- there's no parent/child stdio relationship
// once we're injected, and an abstract socket needs no filesystem permissions to cross from the game's uid to
// the Astral.Oxide app's uid (both on the same device, no netns on Android). The Android app side (EspService)
// connects to this socket instead of spawning ox_core as a subprocess; Model.java's line parser is unchanged.
//
// Protocol: identical to ox_main.cpp's header comment. One client at a time; a new connection replaces the old.
#include "../ox_game.h"
#include "../local_mem.h"
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <sys/socket.h>
#include <sys/un.h>
#include <thread>
#include <unistd.h>

static const char* kSockName = "astral_oxide_ipc";   // abstract namespace: leading NUL added below

static std::mutex g_mu;
static float g_fov = 70.f, g_maxd = 400.f;
static SilentCfg g_sil;
static bool g_noRecoil = false;

static std::string clean(const char* s) {
    std::string o;
    for (; *s; s++) o.push_back((isalnum((unsigned char)*s) || *s == '_' || *s == '.' || *s == '-' || *s == ' ') ? *s : '_');
    return o;
}

static void config_reader(int fd, std::atomic<bool>* alive) {
    char buf[1024];
    std::string pending;
    while (*alive) {
        ssize_t n = recv(fd, buf, sizeof buf, 0);
        if (n <= 0) { *alive = false; return; }
        pending.append(buf, (size_t)n);
        size_t nl;
        while ((nl = pending.find('\n')) != std::string::npos) {
            std::string line = pending.substr(0, nl);
            pending.erase(0, nl + 1);
            if (line.size() < 2 || line[0] != 'C' || line[1] != '|') continue;
            char* save = nullptr;
            std::string body = line.substr(2);
            std::vector<char> raw(body.begin(), body.end());
            raw.push_back('\0');
            for (char* t = strtok_r(raw.data(), ",\r", &save); t; t = strtok_r(nullptr, ",\r", &save)) {
                char* eq = strchr(t, '=');
                if (!eq) continue;
                *eq = 0;
                float v = strtof(eq + 1, nullptr);
                std::lock_guard<std::mutex> l(g_mu);
                if (!strcmp(t, "fov")) g_fov = v; else if (!strcmp(t, "maxd")) g_maxd = v;
                else if (!strcmp(t, "sil")) g_sil.on = v != 0; else if (!strcmp(t, "sbone")) g_sil.bone = (int)v;
                else if (!strcmp(t, "sfov")) g_sil.fovDeg = v; else if (!strcmp(t, "smaxd")) g_sil.maxDist = v;
                else if (!strcmp(t, "norecoil")) g_noRecoil = v != 0;
            }
        }
    }
}

static uint64_t find_il2cpp_base() {
    LocalMem m;
    for (auto& r : m.regions()) if (r.path.find("libil2cpp.so") != std::string::npos) return r.start;
    return 0;
}

static void serve(int cfd) {
    std::atomic<bool> alive{true};
    std::thread(config_reader, cfd, &alive).detach();

    uint64_t base = find_il2cpp_base();
    if (!base) { std::string msg = "N|libil2cpp.so not mapped (odd: we are injected into this process)\n"; send(cfd, msg.data(), msg.size(), MSG_NOSIGNAL); return; }
    LocalMem mem;
    OxGame game(mem, base);
    OxSnap snap;

    while (alive) {
        float fov, maxd;
        { std::lock_guard<std::mutex> l(g_mu); fov = g_fov; maxd = g_maxd; }
        if (!game.update(snap, fov)) {
            game.silent_prepare(false);
            std::string out = std::string("N|") + game.status() + "\n";
            if (send(cfd, out.data(), out.size(), MSG_NOSIGNAL) < 0) return;
            std::this_thread::sleep_for(std::chrono::milliseconds(150));
            continue;
        }
        SilentCfg sil; bool noRecoil;
        { std::lock_guard<std::mutex> l(g_mu); sil = g_sil; noRecoil = g_noRecoil; }
        game.silent_prepare(sil.on);
        game.silent_feed(sil, snap);
        game.patch_recoil(noRecoil);
        std::string out = "S|ok|";
        char b[320];
        snprintf(b, sizeof b, "%.3f,%.3f,%.3f|%.4f,%.4f,%.4f|%.2f|0|", snap.cam.pos.x, snap.cam.pos.y, snap.cam.pos.z, snap.cam.fwd.x, snap.cam.fwd.y, snap.cam.fwd.z, snap.cam.fovY);
        out += b;
        bool first = true;
        for (auto& p : snap.players) {
            if (!p.local && len(p.pos - snap.cam.pos) > maxd) continue;
            snprintf(b, sizeof b, "%s%u,0,%d,%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,", first ? "" : ";", p.id, p.hp, (p.local ? 1 : 0) | (p.dead ? 2 : 0), p.pos.x, p.pos.y, p.pos.z, p.vel.x, p.vel.y, p.vel.z);
            out += b; out += clean(p.name[0] ? p.name : "Player");
            first = false;
        }
        out += "|" + game.diag() + " sil=" + game.silent_status() + " rec=" + game.recoil_status() + "|0,0,0,0,0,-1,0\n";
        if (send(cfd, out.data(), out.size(), MSG_NOSIGNAL) < 0) { game.shutdown_patches(); return; }
        std::this_thread::sleep_for(std::chrono::milliseconds(8));
    }
    game.shutdown_patches();
}

static void run() {
    install_fault_guard();
    int lfd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (lfd < 0) return;
    struct sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    addr.sun_path[0] = '\0';
    strncpy(addr.sun_path + 1, kSockName, sizeof(addr.sun_path) - 2);
    socklen_t len = (socklen_t)(offsetof(struct sockaddr_un, sun_path) + 1 + strlen(kSockName));
    if (bind(lfd, (struct sockaddr*)&addr, len) != 0) { close(lfd); return; }   // already bound -> another copy is already running, exit quietly
    if (listen(lfd, 1) != 0) { close(lfd); return; }
    for (;;) {
        int cfd = accept(lfd, nullptr, nullptr);
        if (cfd < 0) continue;
        serve(cfd);     // blocks until the APK side disconnects; then go back to accept() for the next connection
        close(cfd);
    }
}

__attribute__((constructor)) static void on_load() {
    std::thread(run).detach();
}
