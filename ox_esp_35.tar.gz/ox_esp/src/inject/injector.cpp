// astral_inject <pid> <path-to-so>: loads a shared library into an already-running process via ptrace, by
// hijacking one thread to call the target's own dlopen(path, RTLD_NOW). Runs as root (same as ox_core already
// does for /proc/pid/mem). arm64 only.
//
// How: attach -> find dlopen's address in the TARGET by ASLR-diffing OUR libc.so base against the target's
// libc.so base (same libc file, same relative symbol offset) -> write the path string + a BRK trap onto the
// target's stack (via /proc/pid/mem, since we're root -- no PTRACE_POKEDATA word loop needed) -> point PC at
// dlopen, LR at the trap, X0 at the path, X1 = RTLD_NOW -> PTRACE_CONT -> wait for our own trap to fire ->
// read X0 (dlopen's return, the handle inside the target) -> restore the thread's original registers exactly
// -> detach. The target never sees anything happened except one library now loaded and its constructor having run.
//
// не проверял на реальном устройстве -- ptrace register layouts and the BRK trap are right for arm64/bionic,
// but this class of code is exactly the kind that works on one Android build and not the next. If it hangs the
// target mid-injection: `kill -9 <pid>`, relaunch the game, don't restart without checking what broke first.
#include "../mem.h"
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <fcntl.h>
#include <fstream>
#include <sstream>
#include <string>
#include <sys/ptrace.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <linux/elf.h>

static uint64_t module_base(int pid, const char* needle) {
    char path[64];
    snprintf(path, sizeof path, "/proc/%d/maps", pid);
    std::ifstream f(path);
    std::string line;
    while (std::getline(f, line)) {
        if (line.find(needle) == std::string::npos) continue;
        uint64_t s = strtoull(line.c_str(), nullptr, 16);
        return s;
    }
    return 0;
}

static bool mem_write(int pid, uint64_t addr, const void* data, size_t n) {
    char path[64];
    snprintf(path, sizeof path, "/proc/%d/mem", pid);
    int fd = open(path, O_RDWR);
    if (fd < 0) return false;
    bool ok = pwrite64(fd, data, n, (off_t)addr) == (ssize_t)n;
    close(fd);
    return ok;
}

static bool get_regs(pid_t pid, struct user_pt_regs& regs) {
    struct iovec io{&regs, sizeof regs};
    return ptrace(PTRACE_GETREGSET, pid, (void*)NT_PRSTATUS, &io) == 0;
}
static bool set_regs(pid_t pid, struct user_pt_regs& regs) {
    struct iovec io{&regs, sizeof regs};
    return ptrace(PTRACE_SETREGSET, pid, (void*)NT_PRSTATUS, &io) == 0;
}

int main(int argc, char** argv) {
    // astral_inject -p <pkgs> <path-to-so>   OR   astral_inject --pid <pid> <path-to-so>
    if (argc < 4) { fprintf(stderr, "usage: astral_inject -p <pkgs> <path-to-so>  |  astral_inject --pid <pid> <path-to-so>\n"); return 1; }
    if (getuid() != 0) { fprintf(stderr, "needs root\n"); return 1; }
    pid_t pid = 0;
    std::string soPath;
    if (!strcmp(argv[1], "--pid")) { pid = (pid_t)atoi(argv[2]); soPath = argv[3]; }
    else if (!strcmp(argv[1], "-p")) {
        std::string pkgs = argv[2];
        soPath = argv[3];
        size_t a = 0;
        while (!pid && a <= pkgs.size()) {
            size_t b = pkgs.find(',', a);
            if (b == std::string::npos) b = pkgs.size();
            if (b > a) pid = (pid_t)Proc::find_pid(pkgs.substr(a, b - a));
            a = b + 1;
        }
        if (!pid) { fprintf(stderr, "no running process matched: %s\n", pkgs.c_str()); return 1; }
    } else { fprintf(stderr, "bad args\n"); return 1; }

    uint64_t ourLibc = module_base(getpid(), "/libc.so");
    uint64_t targetLibc = module_base(pid, "/libc.so");
    if (!ourLibc || !targetLibc) { fprintf(stderr, "libc.so not found in our own maps or the target's\n"); return 1; }
    void* dlopenOurs = (void*)dlsym(RTLD_DEFAULT, "dlopen");
    if (!dlopenOurs) { fprintf(stderr, "dlsym(dlopen) failed\n"); return 1; }
    uint64_t dlopenOff = (uint64_t)dlopenOurs - ourLibc;
    uint64_t dlopenTarget = targetLibc + dlopenOff;

    if (ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) != 0) { perror("PTRACE_ATTACH"); return 1; }
    int status = 0;
    waitpid(pid, &status, 0);

    struct user_pt_regs orig{};
    if (!get_regs(pid, orig)) { fprintf(stderr, "GETREGSET failed\n"); ptrace(PTRACE_DETACH, pid, nullptr, nullptr); return 1; }
    struct user_pt_regs work = orig;

    // scratch area well below the current SP, clear of the 128-byte AAPCS64 red zone and of dlopen's own frame
    uint64_t scratch = (work.sp - 4096) & ~0xFull;
    uint64_t pathAddr = scratch;
    uint64_t trapAddr = scratch + 512;

    std::string path0 = soPath; path0.push_back('\0');
    if (!mem_write(pid, pathAddr, path0.data(), path0.size())) { fprintf(stderr, "write path failed\n"); ptrace(PTRACE_DETACH, pid, nullptr, nullptr); return 1; }
    uint32_t brk = 0xd4200000u;   // BRK #0
    if (!mem_write(pid, trapAddr, &brk, 4)) { fprintf(stderr, "write trap failed\n"); ptrace(PTRACE_DETACH, pid, nullptr, nullptr); return 1; }

    work.regs[0] = pathAddr;      // dlopen(path, RTLD_NOW)
    work.regs[1] = 2;             // RTLD_NOW
    work.regs[30] = trapAddr;     // LR: where dlopen's `ret` lands
    work.sp = scratch - 256;      // leave dlopen its own stack below our scratch area
    work.pc = dlopenTarget;
    if (!set_regs(pid, work)) { fprintf(stderr, "SETREGSET failed\n"); ptrace(PTRACE_DETACH, pid, nullptr, nullptr); return 1; }

    if (ptrace(PTRACE_CONT, pid, nullptr, nullptr) != 0) { perror("PTRACE_CONT"); ptrace(PTRACE_DETACH, pid, nullptr, nullptr); return 1; }
    waitpid(pid, &status, 0);
    if (!WIFSTOPPED(status) || WSTOPSIG(status) != SIGTRAP) {
        fprintf(stderr, "target did not stop on our trap (status=%x) -- dlopen likely crashed, restoring regs and detaching\n", status);
        set_regs(pid, orig);
        ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
        return 1;
    }

    struct user_pt_regs after{};
    get_regs(pid, after);
    uint64_t handle = after.regs[0];

    set_regs(pid, orig);          // put the hijacked thread back exactly where it was
    ptrace(PTRACE_DETACH, pid, nullptr, nullptr);

    if (!handle) { fprintf(stderr, "dlopen returned NULL in target -- load failed (bad path, bad ABI, or the lib's own deps missing)\n"); return 1; }
    printf("ok handle=%llx\n", (unsigned long long)handle);
    return 0;
}
