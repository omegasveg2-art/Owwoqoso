// process memory access. Linux-generic (process_vm_readv + /proc/pid/mem fallback), no android deps.
#pragma once
#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

struct Region {
    uint64_t start = 0, end = 0, pgoff = 0;
    bool r = false, w = false, x = false;
    std::string path;
};

struct IMem {
    virtual ~IMem() = default;
    virtual bool read(uint64_t addr, void* out, size_t n) = 0;   // false + zeroed buffer on failure
    virtual std::vector<Region> regions() = 0;
    virtual bool write(uint64_t, const void*, size_t) { return false; }   // optional (weapon mods)
};

// arm64 heap pointers can carry a tag in the top byte (TBI/MTE) -- strip before any syscall / compare
inline uint64_t untag(uint64_t p) { return p & 0x00FFFFFFFFFFFFFFull; }
inline bool plausible_ptr(uint64_t p) { p = untag(p); return p >= 0x10000 && p < 0x0000800000000000ull; }

template <class T> inline T rdv(IMem& m, uint64_t a) { T v{}; m.read(a, &v, sizeof(T)); return v; }
inline uint64_t rdp(IMem& m, uint64_t a) { return untag(rdv<uint64_t>(m, a)); }   // pointer read, tag stripped
inline uint32_t rd32(IMem& m, uint64_t a) { return rdv<uint32_t>(m, a); }
inline uint8_t  rd8 (IMem& m, uint64_t a) { return rdv<uint8_t>(m, a); }
inline float    rdf (IMem& m, uint64_t a) { return rdv<float>(m, a); }

class Proc : public IMem {
public:
    int pid = 0;
    // pid of the main process whose argv[0] contains `needle` (case-insensitive), skipping ":service" children and ourselves
    static int find_pid(const std::string& needle);
    // same, and also hands back the exact package id (raw argv[0], not lowered) so callers don't have to guess it
    static int find_pid(const std::string& needle, std::string& pkgOut);
    bool attach(int p);
    void detach();
    bool alive() const;
    bool read(uint64_t addr, void* out, size_t n) override;
    bool write(uint64_t addr, const void* in, size_t n) override;
    std::vector<Region> regions() override;
    uint64_t module_base(const char* name);   // lowest mapping whose path contains `name`, 0 if none
    ~Proc() override { detach(); }
private:
    int memfd_ = -1;
    bool use_fd_ = false;
};

// Reads a Unity PlayerPrefs value straight off disk: /data/data/<pkg>/shared_prefs/*.xml, standard Android
// SharedPreferences XML that Unity's PlayerPrefsImpl writes on every SetFloat/SetInt/SetString -- format is
// fixed engine behavior (<map><float name="key" value="123" /></map>, or <int>/<string>), not game-specific,
// so this isn't a guess about Oxide itself. Scans every xml in the dir (filename scheme varies: "<pkg>.xml" on
// old Unity, "<pkg>.v2.playerprefs.xml" on newer) and returns the first `name="<key>"` tag's value= as a float.
// `fallback` is returned if root can't read the dir, no file has the key yet (player never touched that
// setting), or the value doesn't parse -- never silently returns 0.
float read_unity_pref_float(const std::string& pkg, const std::string& key, float fallback);

// Same read, plus a short machine-readable reason in `why` for when it falls back: "no_pkg" (pkg empty),
// "no_dir(errno)" (opendir failed -- SELinux is the usual cause even as root on a Magisk/su device, not a
// permission bit problem), "no_xml" (dir opened, zero .xml files in it), "no_key" (xml(s) read fine, "fov"
// key never written -- player hasn't opened Settings>Graphics yet), "bad_value" (key found, didn't parse),
// or "ok".
float read_unity_pref_float(const std::string& pkg, const std::string& key, float fallback, std::string& why);
