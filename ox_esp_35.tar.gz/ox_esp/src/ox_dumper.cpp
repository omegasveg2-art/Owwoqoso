// ox_dumper: standalone, root, read-only runtime dumper for il2cpp games.
//
// Why this exists: every dump the user has supplied so far has turned out to be the wrong version (filename
// didn't match what was actually installed, or the dump predated a patch). The .so and global-metadata.dat
// SITTING ON DISK can also be scrambled on purpose by some protections (packers that keep the real metadata
// encrypted in the APK and only decrypt it into memory at runtime -- "the jammer" in the user's words) so even
// pulling the on-disk file and running Il2CppDumper against it gives garbage or nothing. The fix for both
// problems is the same: dump straight out of the LIVE process's memory, after il2cpp has already loaded and
// (if it was encrypted) decrypted everything -- this is Il2CppDumper's own documented "memory dump" input mode,
// not a new trick; we're just doing the memory read ourselves (same /proc/pid/mem access ox_core already uses,
// no injection, no code execution in the target) instead of asking for a file off disk.
//
// Output: <pkg>.libil2cpp.so.dump and <pkg>.global-metadata.dat.dump in the given directory. Feed BOTH into
// Il2CppDumper, choose "memory dump" mode when it asks (it detects this automatically for most versions, or
// there's an explicit prompt depending on the Il2CppDumper build) -- it fixes up the vaddr/fileoffset mismatch
// a memory-mapped image always has versus an on-disk ELF. Don't rename the files or run them through anything
// else first.
#include "mem.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <unistd.h>

static bool write_file(const std::string& path, const std::vector<uint8_t>& data) {
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return false;
    size_t w = fwrite(data.data(), 1, data.size(), f);
    fclose(f);
    return w == data.size();
}

// dumps [start,end) from `m` in chunks, zero-filling any unreadable page (IMem::read already zeroes on failure,
// so a protected/unmapped sub-range just comes back as zeros instead of aborting the whole dump)
static std::vector<uint8_t> dump_range(IMem& m, uint64_t start, uint64_t end) {
    std::vector<uint8_t> out;
    if (end <= start) return out;
    out.resize((size_t)(end - start));
    const size_t chunk = 1 << 20;
    for (size_t off = 0; off < out.size(); off += chunk) {
        size_t n = std::min(chunk, out.size() - off);
        m.read(start + off, out.data() + off, n);
    }
    return out;
}

// Il2Cpp global-metadata header: sanityCheck (0xFAB11BAF, offset 0) + version (offset 4). Checking both, plus a
// size floor below, is deliberate: a decoy only has to fake 4 bytes to pass a magic-only check, which is exactly
// the "fake 4KB metadata" trick -- real global-metadata.dat for any game with a real class list runs well into
// the hundreds of KB to tens of MB (string table + type/field/method tables), so a few-KB blob failing the size
// floor outs it as a stub even if its header bytes are byte-perfect.
struct MetaCandidate { uint64_t start = 0, end = 0; std::string src; int32_t version = -1; bool magicOk = false; };

static bool check_header(Proc& proc, uint64_t addr, int32_t& versionOut) {
    uint8_t hdr[8] = {0};
    if (!proc.read(addr, hdr, 8)) return false;
    if (!(hdr[0] == 0xAF && hdr[1] == 0x1B && hdr[2] == 0xB1 && hdr[3] == 0xFA)) return false;
    int32_t ver; memcpy(&ver, hdr + 4, 4);
    versionOut = ver;
    return true;
}
static const uint64_t kMetaSizeFloor = 256ull << 10;   // 256 KB -- comfortably above any plausible decoy, comfortably below any real one
static_assert(true, "");   // (looks_like_metadata() removed -- folded into check_header())

// Chunked scan, not page-by-page (per-page 4-byte syscalls across GBs of anon memory is what froze the first
// build). 8MB chunks, buffer searched in RAM. Chunks advance by CH-3 so a magic straddling a chunk edge is
// still seen whole in the next chunk; a match needs i+4<=n so nothing is reported twice. Never reads past the
// region end (that failed the whole read and silently skipped the last chunk before).
static void gather(Proc& proc, const std::vector<Region>& regions, std::vector<MetaCandidate>& cands, bool quiet) {
    for (auto& r : regions) {
        if (r.path.find("global-metadata.dat") == std::string::npos) continue;
        MetaCandidate c; c.start = r.start; c.end = r.end; c.src = "file:" + r.path;
        c.magicOk = check_header(proc, r.start, c.version);
        cands.push_back(c);
    }
    const size_t CH = 8 << 20;
    std::vector<uint8_t> buf(CH);
    uint64_t total = 0, lastMB = 0;
    for (auto& r : regions) {
        if (!r.r || !r.w) continue;
        if (!r.path.empty() && r.path[0] != '[') continue;
        if (r.end - r.start > (1536ull << 20)) continue;
        for (uint64_t off = 0; off + 4 <= r.end - r.start; off += CH - 3) {
            uint64_t addr = r.start + off;
            size_t n = (size_t)std::min<uint64_t>(CH, r.end - addr);
            if (!proc.read(addr, buf.data(), n)) continue;
            for (size_t i = 0; i + 4 <= n; i++) {
                if (buf[i]==0xAF && buf[i+1]==0x1B && buf[i+2]==0xB1 && buf[i+3]==0xFA) {
                    MetaCandidate c; c.start = addr + i; c.end = r.end; c.src = "anon-scan";
                    c.magicOk = check_header(proc, c.start, c.version);
                    cands.push_back(c);
                }
            }
            total += n;
            if (!quiet && (total >> 20) >= lastMB + 256) { lastMB = total >> 20; printf("scanning... %llu MB\n", (unsigned long long)lastMB); }
        }
    }
}
static bool has_good(const std::vector<MetaCandidate>& v) {
    for (auto& c : v) if (c.magicOk && (c.end - c.start) >= kMetaSizeFloor) return true;
    return false;
}

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);   // unbuffered: ProcessBuilder reads us through a pipe, not a tty, so
                                            // fully-buffered stdio would sit on every line until a 4-8KB buffer
                                            // filled or the process exited -- looked exactly like "log started
                                            // then froze" because nothing after the first chunk ever flushed.
    bool waitMode = false;
    { int w = 0; for (int i = 0; i < argc; i++) { if (!strcmp(argv[i], "--wait")) waitMode = true; else argv[w++] = argv[i]; } argc = w; }
    if (argc < 2) {
        printf("usage: ox_dumper [--wait] <pkg-substring[,pkg2,...]> [outdir]\n");
        return 1;
    }
    if (getuid() != 0) { printf("needs root\n"); return 1; }
    std::string pkgs = argv[1];
    std::string outdir = argc > 2 ? argv[2] : ".";

    Proc proc;
    int pid = 0;
    std::string pkgExact;
    size_t a = 0;
    while (!pid && a <= pkgs.size()) {
        size_t b = pkgs.find(',', a);
        if (b == std::string::npos) b = pkgs.size();
        if (b > a) pid = Proc::find_pid(pkgs.substr(a, b - a), pkgExact);
        a = b + 1;
    }
    if (!pid) { printf("process not found for '%s' -- is the game running?\n", pkgs.c_str()); return 1; }
    if (!proc.attach(pid)) { printf("attach failed pid=%d\n", pid); return 1; }
    printf("attached pid=%d pkg=%s\n", pid, pkgExact.c_str());

    auto regions = proc.regions();

    // ---- global-metadata.dat: gather EVERY candidate (don't trust the first match -- a protection can plant a
    // fake few-KB stub under the exact same path, or a fake signature in an anon region, specifically to feed a
    // naive dumper garbage). Every file-backed mapping named global-metadata.dat is one candidate; every r/w anon
    // region whose header passes the magic+version check is another. All of them get validated and sized before
    // picking one, and every candidate found is printed so a fake decoy shows up in the log, not silently.
    std::vector<MetaCandidate> cands;
    gather(proc, regions, cands, false);
    if (waitMode && !has_good(cands)) {
        // The real (decrypted) metadata only shows up once the game is actually loaded past the menu. Keep
        // rescanning every 3s until a magic-valid blob >= 256KB exists (decoy stubs never pass), up to 15 min.
        printf("waiting for real metadata (stub/decoy only so far) -- get INTO the game (spawn in), I'll catch it\n");
        for (int t = 0; t < 300 && !has_good(cands); t++) {
            sleep(3);
            if (!proc.alive()) { printf("game process died\n"); return 1; }
            regions = proc.regions();
            cands.clear();
            gather(proc, regions, cands, true);
            if (t % 10 == 9) printf("still waiting... %ds, %zu candidate(s), none real yet\n", (t + 1) * 3, cands.size());
        }
        if (has_good(cands)) printf("real metadata appeared -- dumping now\n"); else printf("timeout: real metadata never appeared\n");
    }

    if (cands.empty()) {
        printf("global-metadata.dat: 0 candidates found (neither file-backed nor by signature scan) -- can't produce it this run\n");
    } else {
        // dump EVERY candidate to its own file, not just the one picked as "best" -- the decoy is designed to
        // look plausible and the real decrypted copy may only exist once you're actually in-game (past the main
        // menu), not at the moment the DUMP button is pressed at the wrong time. Numbered so nothing is silently
        // thrown away; feed the one that actually looks right (biggest, sane version, sane size) into Il2CppDumper.
        for (size_t i = 0; i < cands.size(); i++) {
            auto& c = cands[i];
            auto img = dump_range(proc, c.start, c.end);
            std::string tag = c.src == "anon-scan" ? "anon" : "file";
            std::string path = outdir + "/" + pkgExact + ".global-metadata." + std::to_string(i) + "." + tag +
                                ".sz" + std::to_string(img.size()) + (c.magicOk ? "" : ".badmagic") + ".dump";
            bool ok = write_file(path, img);
            printf("global-metadata candidate %zu: %s start=0x%llx size=%llu magic=%s version=%d %s -> %s (%s)\n",
                   i, c.src.c_str(), (unsigned long long)c.start, (unsigned long long)(c.end - c.start),
                   c.magicOk ? "ok" : "BAD", c.version,
                   (c.magicOk && (c.end - c.start) >= kMetaSizeFloor) ? "[passes size floor]" : "[too small or bad magic -- likely a decoy]",
                   path.c_str(), ok ? "ok" : "write_failed");
        }
        // best = passes magic AND size floor, largest of those; if NONE pass the floor, fall back to the
        // largest magic-ok one anyway (better than nothing) but the printed warning above makes that visible.
        MetaCandidate* best = nullptr;
        for (auto& c : cands) {
            if (!c.magicOk) continue;
            bool cOk = (c.end - c.start) >= kMetaSizeFloor;
            bool bOk = best && (best->end - best->start) >= kMetaSizeFloor;
            if (!best) { best = &c; continue; }
            if (cOk != bOk) { if (cOk) best = &c; continue; }
            if ((c.end - c.start) > (best->end - best->start)) best = &c;
        }
        if (!best) {
            printf("global-metadata.dat: all %zu candidate(s) failed the magic check -- not dumping garbage\n", cands.size());
        } else {
            auto img = dump_range(proc, best->start, best->end);
            std::string path = outdir + "/" + pkgExact + ".global-metadata.dat.dump";
            bool ok = write_file(path, img);
            printf("global-metadata.dat: CHOSE %s start=0x%llx size=%zu (of %zu candidates) -> %s (%s)\n",
                   best->src.c_str(), (unsigned long long)best->start, img.size(), cands.size(), path.c_str(), ok ? "ok" : "write_failed");
        }
    }

    regions = proc.regions();   // so image dumped LAST, after the game is loaded / metadata caught
    // ---- libil2cpp.so: contiguous flat dump from its lowest mapped address to its highest ----
    uint64_t soLo = UINT64_MAX, soHi = 0;
    for (auto& r : regions) {
        if (r.path.find("libil2cpp.so") == std::string::npos) continue;
        soLo = std::min(soLo, r.start);
        soHi = std::max(soHi, r.end);
    }
    if (soLo == UINT64_MAX) {
        printf("libil2cpp.so: not mapped in this process (wrong pid, or it hasn't loaded yet)\n");
    } else {
        auto img = dump_range(proc, soLo, soHi);
        std::string path = outdir + "/" + pkgExact + ".libil2cpp.so.dump";
        bool ok = write_file(path, img);
        printf("libil2cpp.so: base=0x%llx size=%zu -> %s (%s)\n",
               (unsigned long long)soLo, img.size(), path.c_str(), ok ? "ok" : "write_failed");
    }

    proc.detach();
    return 0;
}
